### Hexlet tests and linter status:
[![Actions Status](https://github.com/marinavasyukova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/marinavasyukova/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/3c4a10d1b77687e60284/maintainability)](https://codeclimate.com/github/marinavasyukova/python-project-49/maintainability)

Brain-even game demonstration

[![asciicast](https://asciinema.org/a/oU96SVjCjfGdo3OSiGhsui2rC.svg)](https://asciinema.org/a/oU96SVjCjfGdo3OSiGhsui2rC)