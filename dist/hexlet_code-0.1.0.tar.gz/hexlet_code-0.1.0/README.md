### Hexlet tests and linter status:
[![Actions Status](https://github.com/marinavasyukova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/marinavasyukova/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/3c4a10d1b77687e60284/maintainability)](https://codeclimate.com/github/marinavasyukova/python-project-49/maintainability)

Brain-even game demonstration

[![asciicast](https://asciinema.org/a/oU96SVjCjfGdo3OSiGhsui2rC.svg)](https://asciinema.org/a/oU96SVjCjfGdo3OSiGhsui2rC)

Brain-calc game demonstration

[![asciicast](https://asciinema.org/a/SdNAnHAgMrpn9ZLm9GeU8aR3d.svg)](https://asciinema.org/a/SdNAnHAgMrpn9ZLm9GeU8aR3d)

Brain-gcd (greatest common divisor) game demonstration

[![asciicast](https://asciinema.org/a/cJZGVkI0KgDjvFjfqgTm4a259.svg)](https://asciinema.org/a/cJZGVkI0KgDjvFjfqgTm4a259)

Brain-progression game demonstration

[![asciicast](https://asciinema.org/a/UjPyvXYgqG6kP0AoLSW55g9jG.svg)](https://asciinema.org/a/UjPyvXYgqG6kP0AoLSW55g9jG)