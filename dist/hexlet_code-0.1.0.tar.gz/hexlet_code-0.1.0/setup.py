# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/marinavasyukova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/marinavasyukova/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/3c4a10d1b77687e60284/maintainability)](https://codeclimate.com/github/marinavasyukova/python-project-49/maintainability)\n\nBrain-even game demonstration\n\n[![asciicast](https://asciinema.org/a/oU96SVjCjfGdo3OSiGhsui2rC.svg)](https://asciinema.org/a/oU96SVjCjfGdo3OSiGhsui2rC)\n\nBrain-calc game demonstration\n\n[![asciicast](https://asciinema.org/a/SdNAnHAgMrpn9ZLm9GeU8aR3d.svg)](https://asciinema.org/a/SdNAnHAgMrpn9ZLm9GeU8aR3d)\n\nBrain-gcd (greatest common divisor) game demonstration\n\n[![asciicast](https://asciinema.org/a/cJZGVkI0KgDjvFjfqgTm4a259.svg)](https://asciinema.org/a/cJZGVkI0KgDjvFjfqgTm4a259)\n\nBrain-progression game demonstration\n\n[![asciicast](https://asciinema.org/a/UjPyvXYgqG6kP0AoLSW55g9jG.svg)](https://asciinema.org/a/UjPyvXYgqG6kP0AoLSW55g9jG)',
    'author': 'Marina Vasyukova',
    'author_email': 'marina.vasyukova@icloud.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
